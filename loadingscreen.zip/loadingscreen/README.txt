We removed the logo we used for testing in order to keep people from trying to make our server.
To add a logo follow the steps below

Navigate to assets/images
Add your logo video you want
Change the name of the file to logo.png

To change the background video navigate to html/index.html:line:11 and insert your mp4 link

For any questions open a ticket in our discord: https://discord.gg/EEWWvnwGDr