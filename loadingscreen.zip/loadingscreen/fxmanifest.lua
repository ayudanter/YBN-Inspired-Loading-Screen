fx_version 'cerulean'
description "YBN Inspired Loading Screen by AR Development"
games { 'gta5' }
lua54 'yes'

author 'ayudanter'
version '1.0'

loadscreen 'build/index.html'
loadscreen_manual_shutdown 'yes'
client_script 'client.lua'
loadscreen_cursor 'yes'

files {
    'build/index.html',
    'build/style.css',   
    'build/script.js',  
    'assets/images/*.png' 
}
